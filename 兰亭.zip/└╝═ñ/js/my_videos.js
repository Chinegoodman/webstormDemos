/**
 * Created by 方艳 on 2016/8/29.
 */
$(function () {
    /*$('#new_details_vedio_out').mouseover(function () {
        $('#video_control').css({display:"block"});
        $('#new_details_vedio_out').mouseout(function () {
            $('#video_control').css({display:"none"});
        })
        $('#video_begin').click(function () {
            
            $('#new_details_vedio').trigger('play');
        })
        $('#video_other').click(function () {

            $('#new_details_vedio').trigger('pause');
        })
    })*/
})